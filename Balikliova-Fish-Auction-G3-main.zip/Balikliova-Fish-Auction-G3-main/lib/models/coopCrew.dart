// class for assigning crewMembers to customers when a sale is done
//will be implemented later
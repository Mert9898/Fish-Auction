import 'package:myapp/models/user.dart';

class CoopHead extends GeneralUser {
  CoopHead(
      {
      required String email,
      required String uid,
      required String name,
      required String username,
      required String phoneNumber})
      : super(
            uid: uid, name: name, username: username, phoneNumber: phoneNumber,email: email);
  


  void denem(){
    
  }
}

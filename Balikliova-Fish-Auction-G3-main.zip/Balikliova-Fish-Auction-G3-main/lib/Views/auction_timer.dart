import 'package:flutter/material.dart';

class AuctionTimer extends StatefulWidget {
  const AuctionTimer({Key? key}) : super(key: key);

  @override
  State<AuctionTimer> createState() => _AuctionTimerState();
}

class _AuctionTimerState extends State<AuctionTimer> {
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Scaffold(),
    );
  }
}
